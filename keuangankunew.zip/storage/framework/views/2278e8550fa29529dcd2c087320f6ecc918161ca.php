<?php $__env->startSection('title', $identitas->deskripsi); ?>

<?php $__env->startSection('content'); ?>
<!-- Services -->
<div id="services" class="cards-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2>Layanan</h2>
            </div> 
        </div> 
        <div class="row">
            <div class="col-lg-12">

                
                
            </div>
        </div>
    </div>
</div>

<?php ($row=1); ?>
<?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($row == 1): ?>
<!-- Details 1 -->
<div class="basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="text-container">
                    <h2><?php echo e($value->title); ?></h2>
                    <?php echo $value->description; ?>

                    <a class="btn-solid-reg popup-with-move-anim" href="<?php echo e(url('/registrasi')); ?>">REGISTRASI</a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="image-container">
                    <img class="img-fluid" src="<?php echo e(asset('public/images/index/'.$value->image)); ?>" alt="alternative">
                </div>
            </div>
        </div>
    </div>
</div>
<?php ($row=2); ?>
<?php elseif($row == 2): ?>
<!-- Details 2 -->
<div class="basic-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="image-container">
                    <img class="img-fluid" src="<?php echo e(asset('public/images/index/'.$value->image)); ?>" alt="alternative">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="text-container">
                    <h2><?php echo e($value->title); ?></h2>
                    <?php echo $value->description; ?>

                    <a class="btn-solid-reg popup-with-move-anim" href="<?php echo e(url('/registrasi')); ?>">REGISTRASI</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php ($row=1); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- About -->
<div id="syarat" class="">
    <div class="ex-basic-2 container" style="">
        <div class="row" style="margin-bottom: 25px;">
            <div class="col-lg-12 text-center">
                <h2><?php echo e($syarat->title); ?></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <div class="text-container">
                    <?php echo $syarat->description; ?>

                </div>
            </div>
        </div>
        <div class="row" style="margin-bottom: 25px;">
            <div class="col-lg-12 text-center">
                <h2><?php echo e($kebijakan->title); ?></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <div class="text-container">
                    <?php echo $kebijakan->description; ?>

                </div>
            </div>
        </div>
    </div>
</div>


<!-- Contact -->
<div id="contact" class="form-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2>Pesan</h2>
                <ul class="list-unstyled li-space-lg">
                    <li class="address">Kirimkan pesan/pertanyaan, kritik, saran Anda kepada Kami.</li>
                    <li class="address"><i>Contact Support : support@keuanganku.info</i></li>
                </ul>
            </div> 
        </div>
        <div class="row">
            <div class="col-lg-12">
                <?php if(Session::has('flash_message_error')): ?>
                <div class="alert alert-warning alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo session('flash_message_error'); ?></strong>
                </div>
                <?php elseif(Session::has('flash_message_success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo session('flash_message_success'); ?></strong>
                </div>
                <?php endif; ?> 

                <form id="contactForm" method="post" data-toggle="validator" data-focus="false" action="<?php echo e(url('/pesan')); ?>"><?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="text" class="form-control-input <?php if(Session::has('cname')): ?> notEmpty <?php endif; ?>" id="cname" name="nama" value="<?php if(Session::has('cname')): ?><?php echo e(session('cname')); ?><?php endif; ?>" required>
                        <label class="label-control" for="cname">Nama</label>
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control-input <?php if(Session::has('cemail')): ?> notEmpty <?php endif; ?>" id="cemail" name="email" value="<?php if(Session::has('cemail')): ?><?php echo e(session('cemail')); ?><?php endif; ?>" required>
                        <label class="label-control" for="cemail">Email</label>
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control-input <?php if(Session::has('csubject')): ?> notEmpty <?php endif; ?>" id="csubject" name="subyek" value="<?php if(Session::has('csubject')): ?><?php echo e(session('csubject')); ?><?php endif; ?>" required>
                        <label class="label-control" for="csubject">Subyek</label>
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control-textarea <?php if(Session::has('cmessage')): ?> notEmpty <?php endif; ?>" id="cmessage" name="pesan" required><?php if(Session::has('cmessage')): ?><?php echo e(session('cmessage')); ?><?php endif; ?></textarea>
                        <label class="label-control" for="cmessage">Pesan Anda...</label>
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <div class="captcha">
                           <span><?php echo captcha_img(); ?></span>
                           <button type="button" class="btn btn-success"><i class="fa fa-sync-alt" id="refresh"></i></button>
                        </div>
                        <input type="text" class="form-control" id="ccaptcha" name="ccaptcha" placeholder="Captcha" autocomplete="off" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="form-control-submit-button">KIRIM PESAN</button>
                    </div>
                    <div class="form-message">
                        <div id="cmsgSubmit" class="h3 text-center hidden"></div>
                    </div>
                </form>

            </div>
        </div> 
    </div>
</div>

<div id="donasi">
    <div class="basic-4 container">
        <div class="row">
            <div class="col-lg-12">
                <h2>Donasi</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 text-center">
                
                <h4><strong>BANK BRI</strong></h4>
                <h4>NO. REK : <span class="norek">0508-01-010795-50-4</span></h4>
                <h6>A.N. AHMAD SYAHRUL YUSUF</h6>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.indexLayout.indexContent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>