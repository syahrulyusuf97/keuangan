<!-- App Sidebar -->
<div class="modal fade panelbox panelbox-left" id="sidebarPanel" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
                <!-- profile box -->
                <div class="profileBox pt-2 pb-2">
                    <div class="image-wrapper">
                        <?php if(auth()->user()->img == ""): ?>
                        <img src="<?php echo e(asset('public/images/default.jpg')); ?>" alt="image" class="imaged w36">
                        <?php else: ?>
                        <img src="<?php echo e(asset('public/images/'. auth()->user()->img)); ?>" alt="image" class="imaged  w36">
                        <?php endif; ?>
                    </div>
                    <div class="in">
                        <strong>
                            <?php echo e(auth()->user()->name); ?>

                        </strong>
                        <div class="text-muted">Member</div>
                    </div>
                    <a href="#" class="btn btn-link btn-icon sidebar-close" data-dismiss="modal">
                        <ion-icon name="close-outline"></ion-icon>
                    </a>
                </div>
                <!-- * profile box -->
                <!-- balance -->
                <div class="sidebar-balance">
                    <div class="listview-title">Saldo</div>
                    <div class="in">
                        <h1 class="amount total-saldo" style="font-size: 20px;"><?php echo e(Helper::displayRupiah(Helper::saldo())); ?></h1>
                    </div>
                </div>
                <!-- * balance -->

                <!-- menu -->
                <ul class="sidebar-k-menu" data-widget="tree">
                  <li class="header">NAVIGASI UTAMA</li>
                  <li>
                    <a href="<?php echo e(url('/dashboard')); ?>" data-turbolinks="true" class="page-redirect">
                      <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                  </li>
                  <li class="treeview">
                    <a href="#">
                      <i class="fa fa-database"></i>
                      <span>Master</span>
                      <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="<?php echo e(url('/master/akun')); ?>" data-turbolinks="true" class="page-redirect"><i class="fa fa-book"></i> Akun</a></li>
                      <li><a href="<?php echo e(url('/master/kategori')); ?>" class="page-redirect"><i class="fa fa-list"></i> Kategori</a></li>
                    </ul>
                  </li>
                  <li class="treeview">
                    <a href="#">
                      <i class="fa fa-bank"></i>
                      <span>Bank</span>
                      <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="<?php echo e(url('/bank/bank-masuk')); ?>" class=""><i class="fa fa-arrow-down"></i> Bank Masuk</a></li>
                      <li><a href="<?php echo e(url('/bank/bank-keluar')); ?>" class="page-redirect"><i class="fa fa-arrow-up"></i> Bank Keluar</a></li>
                    </ul>
                  </li>
                  <li class="treeview">
                    <a href="#">
                      <i class="fa fa-money"></i>
                      <span>Kas</span>
                      <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="<?php echo e(url('/kas/masuk')); ?>" class="page-redirect"><i class="fa fa-arrow-down"></i> Kas Masuk</a></li>
                      <li><a href="<?php echo e(url('/kas/keluar')); ?>" class="page-redirect"><i class="fa fa-arrow-up"></i> Kas Keluar</a></li>
                    </ul>
                  </li>
                  <li class="treeview">
                    <a href="#">
                      <i class="fa fa-list-alt"></i>
                      <span>Laporan</span>
                      <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="<?php echo e(url('/laporan/chart')); ?>" class="page-redirect"><i class="fa fa fa-bar-chart"></i> Chart/Grafik</a></li>
                      <li><a href="<?php echo e(url('/laporan/cashflow')); ?>" class="page-redirect"><i class="fa fa-list"></i> Arus Kas/<i>Cashflow</i></a></li>
                    </ul>
                  </li>
                  <li class="treeview">
                    <a href="#">
                      <i class="fa fa-clock-o"></i>
                      <span>Riwayat</span>
                      <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="<?php echo e(url('/riwayat/aktivitas')); ?>" class="page-redirect"><i class="fa fa-list"></i> Aktivitas</a></li>
                      <li><a href="<?php echo e(url('/riwayat/bank')); ?>" class="page-redirect"><i class="fa fa-bank"></i> Bank</a></li>
                      <li><a href="<?php echo e(url('/riwayat/kas')); ?>" class="page-redirect"><i class="fa fa-money"></i> Kas</a></li>
                    </ul>
                  </li>
                  <li class="header">LAINNYA</li>
                  <li>
                    <a href="<?php echo e(url('/profil')); ?>" data-turbolinks="true" class="page-redirect">
                      <i class="fa fa-gears"></i> <span>Pengaturan</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" data-turbolinks="true" class="logout">
                      <i class="fa fa-sign-out"></i> <span>Keluar</span>
                    </a>
                  </li>
                </ul>

                <!-- 
                <div class="listview-title mt-1">Menu</div>
                <ul class="listview flush transparent no-line image-listview">
                    <li>
                        <a href="<?php echo e(url('/dashboard')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="home-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Dashboard
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/master/akun')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="book-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Master Akun
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/master/kategori')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="document-text-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Master Kategori
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/kas/masuk')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="arrow-down-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Kas Masuk
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/kas/keluar')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="arrow-up-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Kas Keluar
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/bank/bank-masuk')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="arrow-down-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Bank Masuk
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/bank/bank-keluar')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="arrow-up-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Bank Keluar
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/laporan/chart')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="bar-chart-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Statistik
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/laporan/cashflow')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="book-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Arus Kas
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/riwayat/aktivitas')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="list-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Riwayat Aktivitas
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/riwayat/kas')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="wallet-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Riwayat Kas
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/riwayat/bank')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="card-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Riwayat Bank
                            </div>
                        </a>
                    </li>
                </ul> 
                -->
                <!-- * menu -->

                <!-- others -->
                <!--
                <div class="listview-title mt-1">Lainnya</div>
                <ul class="listview flush transparent no-line image-listview">
                    <li>
                        <a href="<?php echo e(url('/profil')); ?>" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="settings-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Pengaturan
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="component-messages.html" class="item page-redirect">
                            <div class="icon-box bg-primary">
                                <ion-icon name="chatbubble-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Bantuan
                            </div>
                        </a>
                    </li> 
                    <li>
                        <a href="#" class="item logout">
                            <div class="icon-box bg-primary">
                                <ion-icon name="log-out-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Keluar
                            </div>
                        </a>
                    </li>
                </ul>
                -->
                <!-- * others -->

            </div>
        </div>
    </div>
</div>
<!-- * App Sidebar -->