<?php $__env->startSection('title', 'Artikel'); ?>

<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs -->
<div class="ex-basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs">
                    <a href="<?php echo e(url('/')); ?>">Beranda</a><i class="fa fa-angle-double-right"></i><span>Artikel</span>
                </div> <!-- end of breadcrumbs -->
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-1 -->
<!-- end of breadcrumbs -->

<!-- Privacy Content -->
<div class="ex-basic-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="text-container">
                    <div class="row">
                        <div class="col-md-8">
                        	<h1><?php echo e($data->title); ?></h1>
                            <?php echo $data->description; ?>

                        </div> <!-- end of col -->

                        <div class="col-md-4 other-article">
                        	<h1>Artikel Lainnya</h1>
                            <ul class="list-unstyled li-space-lg indent">
                                <?php if(count($article_other) > 0): ?>
                            		<?php $__currentLoopData = $article_other; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            			<li class="media">
		                                	<div class="box-border">
				                        		<a href="<?php echo e(url('/article/'.$value->slug)); ?>">
				                        			<h3><?php echo e($value->title); ?></h3>
				                        		    <p><?php echo str_limit(implode("", explode("</p>", implode("", explode("<p>", $value->description)))), 100, '...'); ?></p>
				                        		    <span>Dibuat tanggal : <?php echo e($value->created_at); ?></span>
					                        	</a>
				                        	</div>
		                                </li>
                            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            	<?php else: ?>
			                        <div class="alert alert-success alert-block text-center">
					                    <strong>Belum ada artikel untuk Anda.</strong>
					                </div>
                            	<?php endif; ?>
                            </ul>
                        </div> <!-- end of col -->
                    </div> <!-- end of row -->
                </div> <!-- end of text-container-->
                <a class="btn-outline-reg back" href="<?php echo e(url('/article')); ?>">KEMBALI</a>
            </div> <!-- end of col-->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-2 -->
<!-- end of privacy content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.indexLayout.indexContent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>