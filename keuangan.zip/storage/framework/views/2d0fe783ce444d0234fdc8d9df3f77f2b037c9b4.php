<?php $__env->startSection('title', 'Layanan'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
		Index
		<small>Layanan</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-home"></i> Index</a></li>
		<li class="active">Layanan</li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<?php if(Session::has('flash_message_error')): ?>
			<div class="alert alert-error alert-block">
				<button type="button" class="close" data-dismiss="alert">x</button>
				<strong><?php echo session('flash_message_error'); ?></strong>
			</div>
			<?php endif; ?>
			<?php if(Session::has('flash_message_success')): ?>
			<div class="alert alert-success alert-block">
				<button type="button" class="close" data-dismiss="alert">x</button>
				<strong><?php echo session('flash_message_success'); ?></strong>
			</div>
			<?php endif; ?>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 box">
				<div class="box-header with-border">
					<h3 class="box-title">Layanan</h3>
					<a href="<?php echo e(url('/admin/index/layanan/create')); ?>" class="btn btn-info pull-right"><i class="fa fa-plus"></i> Tambah</a>
				</div>
				<div class="box-body table-responsive">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>Judul</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
						<tfoot>
							<tr>
								<th>Judul</th>
								<th>Aksi</th>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>

<script src="<?php echo e(asset('public/js/jQuery/jquery.min.js')); ?>"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$('#example1').dataTable({
			"processing": true,
			"serverSide": true,
			"ajax": "<?php echo e(route('getLayanan')); ?>",
			"columns":[
				{"data": "judul"},
				{"data": "aksi"}
			]
		})
	})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.adminContent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>