<?php $url = url()->current(); ?>
<!-- <div id="scroll"> -->
<aside class="main-sidebar-k">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar-k">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <?php if(auth()->user()->img == ""): ?>
          <img src="<?php echo e(asset('public/images/default.jpg')); ?>" class="img-circle" alt="User Image">
        <?php else: ?>
          <img src="<?php echo e(asset('public/images/'. auth()->user()->img)); ?>" class="img-circle" alt="User Image">
        <?php endif; ?>
      </div>
      <div class="pull-left info">
        <p>
          <?php if(Session::has('adminName')): ?>
            <?php echo auth()->user()->name; ?>

          <?php endif; ?>
        </p>
        <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>
    <!-- search form -->
    
      
        
        
              
              
            
      
    
    <!-- /.search form -->
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-k-menu" data-widget="tree">
      <li class="header">NAVIGASI UTAMA</li>
      <li>
        <a href="<?php echo e(url('/admin/dashboard')); ?>">
          <i class="fa fa-dashboard"></i> <span>Dashboard</span>
        </a>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-users"></i>
          <span>Member</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/admin/users')); ?>"><i class="fa fa-users"></i> Data Member</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-user"></i>
          <span>Profil</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/admin/profile')); ?>"><i class="fa fa-user"></i> Profil Admin</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-clock-o"></i>
          <span>Riwayat</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/admin/riwayat/aktivitas')); ?>"><i class="fa fa-list"></i> Aktivitas</a></li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('/admin/pesan')); ?>">
          <i class="fa fa-envelope"></i> <span>Pesan Masuk</span>
          <?php if(Helper::countUnread() > 0): ?>
          <span class="pull-right-container">
            <span class="label label-primary pull-right"><?php echo e(Helper::countUnread()); ?></span>
          </span>
          <?php endif; ?>
        </a>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-home"></i>
          <span>Index</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/admin/index/identitas-app')); ?>"><i class="fa fa-circle"></i> Identitas APP</a></li>
          <li><a href="<?php echo e(url('/admin/index/layanan')); ?>"><i class="fa fa-circle"></i> Layanan</a></li>
          <li><a href="<?php echo e(url('/admin/index/syarat')); ?>"><i class="fa fa-circle"></i> Syarat & Ketentuan</a></li>
          <li><a href="<?php echo e(url('/admin/index/kebijakan')); ?>"><i class="fa fa-circle"></i> Kebijakan Privasi</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-list"></i>
          <span>Artikel</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/admin/article')); ?>"><i class="fa fa-circle"></i> Daftar Artikel</a></li>
        </ul>
      </li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>
<!-- </div> -->