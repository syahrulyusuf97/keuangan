<header class="main-header">
	<!-- Logo -->
	<a href="#" class="logo">
		<!-- mini logo for sidebar mini 50x50 pixels -->
		<span class="logo-mini"><b>K</b>KU</span>
		<!-- logo for regular state and mobile devices -->
		<span class="logo-lg"><b>Keuangan</b>KU</span>
	</a>
	<!-- Header Navbar: style can be found in header.less -->
	<nav class="navbar navbar-static-top">
		<!-- Sidebar toggle button-->
		<a href="#" class="sidebar-k-toggle" data-toggle="push-menu" role="button">
			<span class="sr-only">Toggle navigation</span>
		</a>

		<div class="navbar-custom-menu">
			<ul class="nav navbar-nav">
				<li class="dropdown user user-menu">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<?php if(auth()->user()->img == ""): ?>
							<img src="<?php echo e(asset('public/images/default.jpg')); ?>" class="user-image" alt="User Image">
						<?php else: ?>
							<img src="<?php echo e(asset('public/images/'.auth()->user()->img)); ?>" class="user-image" alt="User Image">
						<?php endif; ?>
						<span class="hidden-xs">
							<?php if(Session::has('adminName')): ?>
								<?php echo auth()->user()->name; ?>

					        <?php endif; ?>
						</span>
					</a>
					<ul class="dropdown-menu">
						<!-- User image -->
						<li class="user-header">
							<?php if(auth()->user()->img == ""): ?>
								<img src="<?php echo e(asset('public/images/default.jpg')); ?>" class="img-circle" alt="User Image">
							<?php else: ?>
								<img src="<?php echo e(asset('public/images/'. auth()->user()->img)); ?>" class="img-circle" alt="User Image">
							<?php endif; ?>

							<p>
								<?php if(Session::has('adminName')): ?><?php echo auth()->user()->name; ?><?php endif; ?>
								<small><?php if(auth()->user()->level == 1): ?> Admin <?php elseif(auth()->user()->level == 2): ?> Member <?php endif; ?> KeuanganKu</small>
							</p>
						</li>
						<!-- Menu Footer-->
						<li class="user-footer">
							<div class="pull-left">
								<a href="<?php echo e(url('/admin/profile')); ?>" class="btn btn-default btn-flat">Profil</a>
							</div>
							<div class="pull-right">
								<a href="<?php echo e(url('/logout')); ?>" class="btn btn-default btn-flat">Keluar</a>
							</div>
						</li>
					</ul>
				</li>
				<!-- Control Sidebar Toggle Button -->
				<!-- <li>
					<a href="#" data-toggle="control-sidebar-k"><i class="fa fa-gears"></i></a>
				</li> -->
			</ul>
		</div>
	</nav>
</header>