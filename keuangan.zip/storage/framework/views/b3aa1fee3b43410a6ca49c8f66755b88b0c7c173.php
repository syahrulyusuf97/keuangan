
<?php $__env->startSection('content'); ?>

<div class="login-box">
	<div class="login-logo">
		<a href="#"><b>Keuangan</b>LTE</a>
	</div>
	<!-- /.login-logo -->
	<div class="login-box-body">
		<p class="login-box-msg">Sign in to start your session</p>
		<?php if(Session::has('flash_message_error')): ?>
		<div class="alert alert-error alert-block">
			<button type="button" class="close" data-dismiss="alert">x</button>
			<strong><?php echo session('flash_message_error'); ?></strong>
		</div>
		<?php endif; ?>
		<?php if(Session::has('flash_message_success')): ?>
		<div class="alert alert-success alert-block">
			<button type="button" class="close" data-dismiss="alert">x</button>
			<strong><?php echo session('flash_message_success'); ?></strong>
		</div>
		<?php endif; ?> 
		<form action="<?php echo e(url('/login')); ?>" method="post">
			<?php echo e(csrf_field()); ?>

			<div class="form-group has-feedback">
				<input type="email" name="email" id="email" class="form-control" autofocus placeholder="Email"">
				<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
			</div>
			<div class="form-group has-feedback">
				<input type="password" name="password" id="password" class="form-control" placeholder="Password">
				<span class="glyphicon glyphicon-lock form-control-feedback"></span>
			</div>
			<div class="row">
				<div class="col-xs-8">
					<div class="checkbox icheck">
						<label>
							<input type="checkbox" name="remember" id="remember"> Remember Me
						</label>
					</div>
				</div>
				<!-- /.col -->
				<div class="col-xs-4">
					<button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
				</div>
				<!-- /.col -->
			</div>
		</form>
		<!-- /.social-auth-links -->

		<a href="<?php echo e(route('password.request')); ?>">I forgot my password</a><br>

	</div>
	<!-- /.login-box-body -->
</div>

<script src="<?php echo e(asset('assets/js/jQuery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('assets/js/bootstrap/bootstrap.min.js')); ?>"></script>
<!-- iCheck -->
<script src="<?php echo e(asset('assets/js/iCheck/icheck.min.js')); ?>"></script>
<script>
	$(function () {
		$('input').iCheck({
			checkboxClass: 'icheckbox_square-blue',
			radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
  });
	});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sign.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>