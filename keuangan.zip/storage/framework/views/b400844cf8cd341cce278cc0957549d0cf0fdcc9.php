<?php $__env->startSection('title', 'Identitas APP'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
		Index
		<small>Identitas APP</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-home"></i> Index</a></li>
		<li class="active">Identitas APP</li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<?php if(Session::has('flash_message_error')): ?>
			<div class="alert alert-error alert-block">
				<button type="button" class="close" data-dismiss="alert">x</button>
				<strong><?php echo session('flash_message_error'); ?></strong>
			</div>
			<?php endif; ?>
			<?php if(Session::has('flash_message_success')): ?>
			<div class="alert alert-success alert-block">
				<button type="button" class="close" data-dismiss="alert">x</button>
				<strong><?php echo session('flash_message_success'); ?></strong>
			</div>
			<?php endif; ?>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 box">
				<div class="box-header with-border">
					<h3 class="box-title">Identitas APP</h3>
					<?php if($edit == "true"): ?>
					<a href="<?php echo e(url('/admin/index/identitas-app')); ?>" class="btn btn-warning pull-right"><i class="fa fa-times"></i> Batal</a>
					<?php else: ?>
					<a href="<?php echo e(url('/admin/index/identitas-app?edit=true')); ?>" class="btn btn-warning pull-right"><i class="fa fa-pencil"></i> Edit</a>
					<?php endif; ?>
				</div>
				<form class="form-horizontal" method="post" action="<?php echo e(url('/admin/index/identitas-app')); ?>" id="form_submit"><?php echo e(csrf_field()); ?>

					<input type="hidden" name="id" value="<?php echo e(Crypt::encrypt($data->id)); ?>">
					<div class="box-body">
						<div class="form-group">
							<label for="title" class="col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label">Judul</label>

							<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
								<input type="text" name="title" id="title" class="form-control" value="<?php echo e($data->title); ?>" required <?php if($edit == "false"): ?> readonly <?php endif; ?> />
							</div>
						</div>
						<div class="form-group">
							<label for="title" class="col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label">Deskripsi</label>

							<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
								<textarea class="form-control" id="deskripsi" name="deskripsi" rows="6" required <?php if($edit == "false"): ?> readonly <?php endif; ?>><?php echo e($data->deskripsi); ?></textarea>
							</div>
						</div>
					</div>
					<!-- /.box-body -->
					<div class="box-footer">
						<?php if($edit == "true"): ?>
						<button type="submit" class="btn btn-info pull-right" id="btn_submit"><i class="fa fa-save"></i> Simpan</button>
						<?php endif; ?>
					</div>
					<!-- /.box-footer -->
				</form>
			</div>
		</div>
	</div>
</section>

<script src="<?php echo e(asset('public/js/jQuery/jquery.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.adminContent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>