<?php $__env->startSection('title', 'Detail Saldo'); ?>

<?php $__env->startSection('content'); ?>

<section class="content-header">
	<h1>
		Dashboard
		<small>Detail Saldo <?php echo e(ucwords($param)); ?></small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li class="active">Detail Saldo <?php echo e(ucwords($param)); ?></li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 box box-primary">
				<div class="box-header with-border">
					<h3 class="box-title">Detail Saldo <?php echo e(ucwords($param)); ?></h3>
				</div>
				<div class="box-body table-responsive">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Akun</th>
								<th>Saldo</th>
							</tr>
						</thead>
						<tbody>
						<?php if(count($data) > 0): ?>
						<?php ($total=0); ?>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>(<?php echo e($value->kode_akun); ?>) <?php echo e($value->nama_akun); ?></td>
							<td><?php echo e(Helper::displayRupiah($value->saldo)); ?></td>
						</tr>
						<?php ($total+=$value->saldo); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						</tbody>
						<tfoot>
							<tr>
								<th>Total</th>
								<th><?php echo e(Helper::displayRupiah($total)); ?></th>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>

<script src="<?php echo e(asset('public/js/jQuery/jquery.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.memberLayout.memberContent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>