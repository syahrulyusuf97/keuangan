<header class="main-header">
	<!-- Logo -->
	<a href="index2.html" class="logo">
		<!-- mini logo for sidebar mini 50x50 pixels -->
		<span class="logo-mini"><b>K</b>KU</span>
		<!-- logo for regular state and mobile devices -->
		<span class="logo-lg"><b>Keuangan</b>KU</span>
	</a>
	<!-- Header Navbar: style can be found in header.less -->
	<nav class="navbar navbar-static-top">
		<!-- Sidebar toggle button-->
		<a href="#" class="sidebar-k-toggle" data-toggle="push-menu" role="button">
			<span class="sr-only">Toggle navigation</span>
		</a>

		<div class="navbar-custom-menu">
			<ul class="nav navbar-nav">
				<!-- User Account: style can be found in dropdown.less -->
				<li class="dropdown tasks-menu">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
		              <!-- <i class="fa fa-flag-o"></i>
		              <span class="label label-danger">9</span> -->
		              <span class="saldo">Saldo = <?php echo e(Helper::displayRupiah(Helper::saldo())); ?></span>
		            </a>
		            <ul class="dropdown-menu">
		              <li class="header">Detail Saldo</li>
		              <li>
		                <!-- inner menu: contains the actual data -->
		                <ul class="menu">
		                  <li><!-- Task item -->
		                    <a href="#">
		                      <h3>
		                        Bank
		                        <span class="pull-right"><?php echo e(Helper::displayRupiah(Helper::saldoBank())); ?></span>
		                      </h3>
		                      <!-- <div class="progress xs">
		                        <div class="progress-bar progress-bar-aqua" style="width: 20%" role="progressbar"
		                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
		                          <span class="sr-only">20% Complete</span>
		                        </div>
		                      </div> -->
		                    </a>
		                  </li>
		                  <!-- end task item -->
		                  <li><!-- Task item -->
		                    <a href="#">
		                      <h3>
		                        Kas
		                        <span class="pull-right"><?php echo e(Helper::displayRupiah(Helper::saldoKas())); ?></span>
		                      </h3>
		                      <!-- <div class="progress xs">
		                        <div class="progress-bar progress-bar-green" style="width: 40%" role="progressbar"
		                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
		                          <span class="sr-only">40% Complete</span>
		                        </div>
		                      </div> -->
		                    </a>
		                  </li>
		                </ul>
		              </li>
		              <li class="footer">
		                <!-- <a href="#">View all tasks</a> -->
		              </li>
		            </ul>
          		</li>
				<li class="dropdown user user-menu">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<?php if(auth()->user()->img == ""): ?>
							<img src="<?php echo e(asset('public/images/default.jpg')); ?>" class="user-image" alt="User Image">
						<?php else: ?>
							<img src="<?php echo e(asset('public/images/'.auth()->user()->img)); ?>" class="user-image" alt="User Image">
						<?php endif; ?>
						<span class="hidden-xs">
							<?php if(Session::has('adminName')): ?>
								<?php echo auth()->user()->name; ?>

					        <?php endif; ?>
						</span>
					</a>
					<ul class="dropdown-menu">
						<!-- User image -->
						<li class="user-header">
							<img src="<?php echo e(asset('public/images/'. auth()->user()->img)); ?>" class="img-circle" alt="User Image">

							<p>
								<?php if(Session::has('adminName')): ?><?php echo auth()->user()->name; ?><?php endif; ?>
								<small><?php if(auth()->user()->level == 1): ?> Admin <?php elseif(auth()->user()->level == 2): ?> Member <?php endif; ?> KeuanganKu</small>
							</p>
						</li>
						<!-- Menu Footer-->
						<li class="user-footer">
							<div class="pull-left">
								<a href="<?php echo e(url('/profil')); ?>" class="btn btn-default btn-flat">Profil</a>
							</div>
							<div class="pull-right">
								<a href="<?php echo e(url('/logout')); ?>" class="btn btn-default btn-flat">Keluar</a>
							</div>
						</li>
					</ul>
				</li>
				<!-- Control Sidebar Toggle Button -->
				<!-- <li>
					<a href="#" data-toggle="control-sidebar-k"><i class="fa fa-gears"></i></a>
				</li> -->
			</ul>
		</div>
	</nav>
</header>