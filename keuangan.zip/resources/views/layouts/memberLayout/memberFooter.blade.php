<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>Version</b> 1.0.0
	</div>
	<strong>Copyright &copy; {{\Carbon\Carbon::now()->format('Y')}} <a href="{{url('/')}}">KeuanganKu</a>.</strong> All rights reserved.
</footer>

<!-- <div class="control-sidebar-k-bg"></div> -->