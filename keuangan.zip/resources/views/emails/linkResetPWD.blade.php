<!DOCTYPE html>

<html>

<head>

	<title>Reset Password</title>

</head>

<body>
	<center><strong><h1>KeuanganKu.info</h1></strong></center>

	<h1>Reset Password</h1>

	<p>Kami telah menerima permintaan perubahan kata sandi</p>

	<p>Klik link dibawah ini untuk mengkonfirmasi perubahan kata sandi : </p>

	{{$link}}

	<strong><p>Abaikan pesan ini jika Anda merasa tidak meminta perubahan kata sandi.</p></strong>

</body>

</html>