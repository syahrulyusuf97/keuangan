<!DOCTYPE html>

<html>

<head>

	<title>Informasi Akun</title>

</head>

<body>
	<center><strong><h1>KeuanganKu.info</h1></strong></center>

	<h1>Informasi Akun</h1>

	<p>Email : {{$email}}</p>

	<p>Username : {{$username}}</p>

	<p>Password : {{$password}}</p>

	<p>WEBSITE : <a href="{{url('/')}}">KeuanganKu.info</a></p>

</body>

</html>