<!DOCTYPE html>

<html>

<head>

	<title>Pesan Baru</title>

</head>

<body>
	<center><strong><h1>KeuanganKu.info</h1></strong></center>

	<p>Anda menerima pesan baru dari :</p>

	<p>Nama : {{$name}}</p>

	<p>Email : {{$email}}</p>

	<p>Subyek : {{$subject}}</p>

	<p>Pesan : </p>

	<p><i>{{$pesan}}</i></p>

	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<p>WEBSITE : <a href="{{url('/')}}">KeuanganKu.info</a></p>

</body>

</html>