<!-- app footer -->
<div class="appFooter">
    <div class="footer-title">
        Copyright © KeuanganKu 2020. All Rights Reserved.
    </div>
</div>
<!-- * app footer -->