<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Konfirmasi EMail</h1>
	<p>Klik link berikut ini untuk konfirmasi.</p>
	<a href="{{url('/konfirmasi/'.$userID)}}">{{url('/konfirmasi/'.$userID)}}</a>
</body>
</html>