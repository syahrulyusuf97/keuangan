# KeuanganKu

![GitHub issues](https://img.shields.io/github/issues/syahrulyusuf97/keuangan.svg)

Aplikasi KeuanganKu adalah aplikasi untuk manajemen keuangan pribadi.

URL : https://www.keuanganku.info

Semoga aplikasi ini dapat membantu anda dalam mengelola keuangan pribadi Anda.

### Terima Kasih ...