<?php $url = url()->current(); ?>
<!-- <div id="scroll"> -->
<aside class="main-sidebar-k">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar-k">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <?php if(auth()->user()->img == ""): ?>
          <img src="<?php echo e(asset('public/images/default.jpg')); ?>" class="img-circle" alt="User Image">
        <?php else: ?>
          <img src="<?php echo e(asset('public/images/'. auth()->user()->img)); ?>" class="img-circle" alt="User Image">
        <?php endif; ?>
      </div>
      <div class="pull-left info">
        <p>
          <?php echo e(auth()->user()->name); ?>

        </p>
        <a href="#"><i class="fa fa-circle"></i> <?php echo e(Helper::userOnlineStatus(Crypt::encrypt(auth()->user()->id))); ?></a>
      </div>
    </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-k-menu" data-widget="tree">
      <li class="header">NAVIGASI UTAMA</li>
      <li>
        <a href="<?php echo e(url('/dashboard')); ?>" data-turbolinks="true">
          <i class="fa fa-dashboard"></i> <span>Dashboard</span>
        </a>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-database"></i>
          <span>Master</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/master/akun')); ?>" data-turbolinks="true"><i class="fa fa-book"></i> Akun</a></li>
          <li><a href="<?php echo e(url('/master/kategori')); ?>"><i class="fa fa-list"></i> Kategori</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-bank"></i>
          <span>Bank</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/bank/bank-masuk')); ?>"><i class="fa fa-arrow-down"></i> Bank Masuk</a></li>
          <li><a href="<?php echo e(url('/bank/bank-keluar')); ?>"><i class="fa fa-arrow-up"></i> Bank Keluar</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-money"></i>
          <span>Kas</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/kas/masuk')); ?>"><i class="fa fa-arrow-down"></i> Kas Masuk</a></li>
          <li><a href="<?php echo e(url('/kas/keluar')); ?>"><i class="fa fa-arrow-up"></i> Kas Keluar</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-list-alt"></i>
          <span>Laporan</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/laporan/chart')); ?>"><i class="fa fa fa-bar-chart"></i> Chart/Grafik</a></li>
          <li><a href="<?php echo e(url('/laporan/cashflow')); ?>"><i class="fa fa-list"></i> Arus Kas/<i>Cashflow</i></a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-clock-o"></i>
          <span>Riwayat</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo e(url('/riwayat/aktivitas')); ?>"><i class="fa fa-list"></i> Aktivitas</a></li>
          <li><a href="<?php echo e(url('/riwayat/bank')); ?>"><i class="fa fa-bank"></i> Bank</a></li>
          <li><a href="<?php echo e(url('/riwayat/kas')); ?>"><i class="fa fa-money"></i> Kas</a></li>
        </ul>
      </li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>
<!-- </div> -->