<?php $__env->startSection('title', 'Mail Box'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
		Dashboard
		<small>Email</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-users"></i> Email</a></li>
		<li class="active">Email Masuk</li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<?php if(Session::has('flash_message_error')): ?>
			<div class="alert alert-error alert-block">
				<button type="button" class="close" data-dismiss="alert">x</button>
				<strong><?php echo session('flash_message_error'); ?></strong>
			</div>
			<?php endif; ?>
			<?php if(Session::has('flash_message_success')): ?>
			<div class="alert alert-success alert-block">
				<button type="button" class="close" data-dismiss="alert">x</button>
				<strong><?php echo session('flash_message_success'); ?></strong>
			</div>
			<?php endif; ?>
		</div>
		<div class="col-md-3">
			<a href="#" class="btn btn-primary btn-block margin-bottom"><i class="fa fa-pencil"></i> Compose</a>

			<div class="box box-solid">
				<div class="box-header with-border">
				  <h3 class="box-title">Folders</h3>

				  <div class="box-tools">
				    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
				    </button>
				  </div>
				</div>
				<div class="box-body no-padding">
				  <ul class="nav nav-pills nav-stacked">
				    <li class="folder active" data-folder="inbox"><a href="#" onclick="changeFolder($(this))"><i class="fa fa-inbox"></i> Inbox</a></li>
				    <li class="folder" data-folder="sent"><a href="#" onclick="changeFolder($(this))"><i class="fa fa-envelope-o"></i> Sent</a></li>
				    <li class="folder" data-folder="draft"><a href="#" onclick="changeFolder($(this))"><i class="fa fa-file-text-o"></i> Drafts</a></li>
				    <li class="folder" data-folder="junk"><a href="#" onclick="changeFolder($(this))"><i class="fa fa-filter"></i> Junk</a>
				    </li>
				    <li class="folder" data-folder="trash"><a href="#" onclick="changeFolder($(this))"><i class="fa fa-trash-o"></i> Trash</a></li>
				  </ul>
				</div>
				<!-- /.box-body -->
			</div>
			<!-- /. box -->
			<div class="box box-solid">
				<div class="box-header with-border">
				  <h3 class="box-title">Labels</h3>

				  <div class="box-tools">
				    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
				    </button>
				  </div>
				</div>
				<div class="box-body no-padding">
				  <ul class="nav nav-pills nav-stacked">
				    <li><a href="#"><i class="fa fa-circle-o text-red"></i> Important</a></li>
				    <li><a href="#"><i class="fa fa-circle-o text-yellow"></i> Promotions</a></li>
				    <li><a href="#"><i class="fa fa-circle-o text-light-blue"></i> Social</a></li>
				  </ul>
				</div>
			<!-- /.box-body -->
			</div>
			<!-- /.box -->
		</div>
			<!-- /.col -->
		<div class="col-md-9">
			<div class="box box-primary">
				<div class="nav-tabs-custom" id="page_inbox">
					<ul class="nav nav-tabs">
					  <li class="active"><a href="#tab_1" data-toggle="tab">New</a></li>
					  <li><a href="#tab_2" data-toggle="tab">Seen</a></li>
					  <li><a href="#tab_3" data-toggle="tab">Unseen</a></li>
					</ul>
					<div class="tab-content">
						<div class="tab-pane active" id="tab_1">
							<div class="box-header with-border">
								<h3 class="box-title">NEW</h3>
								<div class="pull-right">
								  <div class="btn-group">
								    <button type="button" class="btn btn-default btn-sm" onclick="refreshTable('tb_new')"><i class="fa fa-refresh"></i></button>
								  </div>
								</div>
							</div>
							<div class="box-body">
								<table id="tb_new" class="table table-bordered table-striped table-responsive">
									<thead>
										<tr>
											<th>From</th>
											<th>Subject</th>
											<th>Date</th>
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
							</div>
						</div>
						<!-- /.tab-pane -->
						<div class="tab-pane" id="tab_2">
							<div class="box-header with-border">
								<h3 class="box-title">SEEN</h3>
								<div class="pull-right">
								  <div class="btn-group">
								    <button type="button" class="btn btn-default btn-sm" onclick="refreshTable('tb_seen')"><i class="fa fa-refresh"></i></button>
								  </div>
								</div>
							</div>
							<div class="box-body">
								<table id="tb_seen" class="table table-bordered table-striped table-responsive" style="width: 100%">
									<thead>
										<tr>
											<th>From</th>
											<th>Subject</th>
											<th>Date</th>
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
							</div>
						</div>
						<div class="tab-pane" id="tab_3">
							<div class="box-header with-border">
								<h3 class="box-title">UNSEEN</h3>
								<div class="pull-right">
								  <div class="btn-group">
								    <button type="button" class="btn btn-default btn-sm" onclick="refreshTable('tb_unseen')"><i class="fa fa-refresh"></i></button>
								  </div>
								</div>
							</div>
							<div class="box-body">
								<table id="tb_unseen" class="table table-bordered table-striped table-responsive" style="width: 100%">
									<thead>
										<tr>
											<th>From</th>
											<th>Subject</th>
											<th>Date</th>
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>

				<div id="page_sent" style="display: none">
					<div class="box-header with-border">
						<h3 class="box-title">NEW</h3>
						<div class="pull-right">
						  <div class="btn-group">
						    <button type="button" class="btn btn-default btn-sm" onclick="refreshTable('tb_sent')"><i class="fa fa-refresh"></i></button>
						  </div>
						</div>
					</div>
					<div class="box-body">
						<table id="tb_new" class="table table-bordered table-striped table-responsive">
							<thead>
								<tr>
									<th>To</th>
									<th>Subject</th>
									<th>Date</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- /. box -->
		</div>
			<!-- /.col -->
	</div>
</section>

<script src="<?php echo e(asset('public/js/jQuery/jquery.min.js')); ?>"></script>
<script type="text/javascript">
	let tb_new, tb_seen, tb_unseen;
	$(function(){
		tb_new = $('#tb_new').dataTable({
			"processing": true,
			"serverSide": true,
			"ajax": "<?php echo e(route('email.getNew')); ?>",
			"columns":[
				{"data": "from"},
				{"data": "subject"},
				{"data": "date"}
			]
		});

		tb_seen = $('#tb_seen').dataTable({
			"processing": true,
			"serverSide": true,
			"ajax": "<?php echo e(route('email.getSeen')); ?>",
			"columns":[
				{"data": "from"},
				{"data": "subject"},
				{"data": "date"}
			]
		});

		tb_unseen = $('#tb_unseen').dataTable({
			"processing": true,
			"serverSide": true,
			"ajax": "<?php echo e(route('email.getUnseen')); ?>",
			"columns":[
				{"data": "from"},
				{"data": "subject"},
				{"data": "date"}
			]
		});
	})

	function refreshTable(param) {
		if (param == 'tb_new') {tb_new.api().ajax.reload()}else if(param == 'tb_seen'){tb_seen.api().ajax.reload()}else if(param == 'tb_unseen'){tb_unseen.api().ajax.reload()}
	}

	function changeFolder(this_) {
		$(".folder").removeClass("active");
		this_.parent().addClass('active');
		if (this_.parent().data('folder') == "inbox") {
			$("#page_inbox").css('display', 'block');
			$("#page_sent").css('display', 'none');
		} else if (this_.parent().data('folder') == "sent") {
			$("#page_inbox").css('display', 'none');
			$("#page_sent").css('display', 'block');
		} else if (this_.parent().data('folder') == "draft") {} else if (this_.parent().data('folder') == "junk") {} else if (this_.parent().data('folder') == "trash") {}
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.adminContent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>